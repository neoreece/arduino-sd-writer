/*
  SDWriter.h - Library for writing to an SD card via SPI.
  Created by Reece Chimento, October 23 2019
*/

#ifndef SDWriter_h
#define SDWriter_h

#include "Arduino.h"

class SDWriter {
  public:
    SDWriter(const int SS_pin);
    bool initiailizeComponent();
    bool write(String outputFilename, String data);
  private:
    int SS_pin;
};

#endif