/*
  SDWriter.h - Library for writing to an SD card via SPI.
  Created by Reece Chimento, October 23 2019
*/
#include <SPI.h>
#include <SD.h>
#include "Arduino.h"
#include "SDWriter.h"

/**
 * Constructs an SD writer to write data to a file.
 */
SDWriter::SDWriter(const int SS_pin)
{
  this->SS_pin = SS_pin;
}

/**
 * Returns true if a the SD card is accessible.
 */
bool SDWriter::initiailizeComponent()
{
  bool isSuccessful;

  if (SD.begin(this->SS_pin)) {
    isSuccessful = true;
  } else {
    isSuccessful = false;
  }

  return isSuccessful;
}

/**
 * Returns true if the file was written.
 */
bool SDWriter::write(String outputFilename, String data)
{
  bool isSuccessful;

  File dataFile = SD.open(outputFilename, FILE_WRITE);
  if (dataFile) {
    dataFile.println(data);
    dataFile.close();
    isSuccessful  = true;
  } else {
    isSuccessful  = false;
  }

  return isSuccessful;
}